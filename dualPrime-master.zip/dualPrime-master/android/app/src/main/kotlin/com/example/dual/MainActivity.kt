package com.example.dual

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
